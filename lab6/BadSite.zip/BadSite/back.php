<!-- Author: Sarah Carruthers
 contains footer info for all pages
 Spring 2020
 Modified by:
--> </div>
 </main><!-- /.container -->
	<footer class="container-fluid bg-4 text-center"><p><small>Copyright &copy;2019 <?php echo $name;?></small></p></footer>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <!--<script src="../bootstrap-4.0.0-dist/js/vendor/popper.min.js"></script>-->
    <script src="https://npmcdn.com/tether@1.2.4/dist/js/tether.min.js"></script>
    <script src="../bootstrap-4.0.0-dist/js/bootstrap.min.js"></script>
  </body>
</html>
