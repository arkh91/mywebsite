//RamSpace.cpp - implementation of RamSpace class
#include <stdio.h>
#include "RamSpace.h"

//Methods for class RamSpace
RamSpace::RamSpace(int size) {
   ramsize = size;
   blockram = new BlockRam(size);
}

RamSpace::~RamSpace() {
   delete blockram;
}

void RamSpace::write(int address, char byte){}
char RamSpace::read(int address){}
