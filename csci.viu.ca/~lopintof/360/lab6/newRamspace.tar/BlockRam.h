//BlockRam.h

class BlockRam {
public:
   BlockRam(int ramsize);
  ~BlockRam();
private:
   const int BLOCKSIZE = 10;
   char *linuxram;
   int nblocks;
};
