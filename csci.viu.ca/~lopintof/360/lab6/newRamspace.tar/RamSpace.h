//RamSpace.h - class definitions for RAM simulator.
//October, 2016
#include "BlockRam.h"

class RamSpace {
public:
   RamSpace(int bytes); //ctor
  ~RamSpace();          //dtor  

   void write(int address, char byte);
   char read(int address);

private:
   BlockRam *blockram;
   int ramsize;
};

