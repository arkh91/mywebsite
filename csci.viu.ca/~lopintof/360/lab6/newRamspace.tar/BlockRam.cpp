#include <stdio.h>
#include "BlockRam.h"

BlockRam::BlockRam(int ramsize) { //ctor
   //Compute number of blocks needed to hold ram of this size
   nblocks = ramsize / BLOCKSIZE;
   if(ramsize > BLOCKSIZE*nblocks) nblocks++;

   linuxram = new char[nblocks*BLOCKSIZE];
   printf("BlockRam ctor: linuxram = 0x%x, size = %d\n",
           linuxram, nblocks*BLOCKSIZE);
}

BlockRam::~BlockRam() { //dtor
   delete linuxram;
   printf("Deleted linuxram\n");
}
